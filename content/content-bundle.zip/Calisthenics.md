[[Weighted Calisthenics Spartan Routine]]

