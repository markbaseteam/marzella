---
created: 2023-09-17
tags:
  - 0🌲
---
It’s extremely tempting to fill spare moments with activity: books, tasks, web browsing, chat. [Culturally default behaviors fill spare time with others’ ideas](https://notes.andymatuschak.org/zMmH3GBLKotdP4t1sdSvEQJ); to make space for my own, I have to get comfortable with “empty” time. I find I often have to get bored before I can [[Get curious]]

So the exhortation is: when you find yourself bored, stay with that feeling instead of immediately reaching for a book or other activity.

Related: [[A rigid fixation on “focus” can harm creative work]]