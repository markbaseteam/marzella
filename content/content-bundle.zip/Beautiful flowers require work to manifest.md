---
created: 2023-09-19
tags:
  - 0🌲
---
There’s building to create something beautiful.

And then there’s building to maintain for the cheapest price.

The Romans built for beautiful.

[[True ownership comes from creating something beautiful.]]

America now builds to maintain. The most profitable.

Do you know what the easiest to maintain plants are? 

Desert shrubs.

They sit there. They don’t need watering. 

But guess what?

They’re an ugly plant.

They don't flower.

They're usually sharp and dangerous.