Anything new for the first time we typically look at the problem from the wrong side.

You subsidise that work by buying the surface level things: the racing bathers, the $2,000 music plugin, the course, the fancy dinner for the Instagram photo.

In reality these things only add 5%. But the reason they’re sexy is because they represent a visual change, it’s a material change which is easier for us to conceptualise rather than process or work which is very abstract. [[Salience of improvement drives skill development]].

In pursuing the outcome you miss the work that will enable to outcome.

All the while you are not cultivating anything worthwhile. You’re not interesting ([[Be interesting]]).