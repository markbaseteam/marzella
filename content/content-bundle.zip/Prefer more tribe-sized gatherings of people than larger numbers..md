
Instead of throngs, opt for tribe-like assemblies, no more than 30—a figure rooted in Stone Age social structures and seemingly a natural limit for meaningful connections. Public spaces like bars or clubs often feel off-putting; they lack the pre-validated community found in friendship circles.

>  "The only people you'll meet at events are people who want something from you or aren't meaningfully engaged in a pursuit of their own. Bored people are losers."

Recurring dinners or cocktail nights prove particularly effective. The setting filters out random passersby, leaving room only for those who share existing bonds with you.

See: [[Be interesting]]