Risk is what could happen after you think you’ve covered all the bases.

…via risk & hedging

Mitigating against losses is more about “hedging” than it is about “diversification”

For instance, you can have a 100% hedged portfolio of just real estate, IF the portfolio is _****good****_ and designed for _********antifragility.********_ A part-timer will think they need “diversification” (a little in the stock market, a little in real estate, a little elsewhere etc) — but if they aren’t heding the diversified investments, they’re still gambling.

Hedging > Diversification. Not all diversified things are hedged and to hedge doesn’t always REQUIRE diversification. If something isn’t protected from loss without compromising the upside, IT IS NOT HEDGED.

Definition: protect the downside without compromising the upside.

### Primary Risks To Mitigate

- The ability to pay rent on time (job stability & job growth)
- The rate of growth in the city (for filling homes with good tenants)
- The historical fragility of the market (during recessions, how does city handle)
- The renter VS owner percentage (demand determines rent to value ratios)
- Economic value of time to return compared to your other oppotunties

**The goal is to increase your income as you divest into assets…**