No barbells, no machines Only bodyweight and DB exercises 

Myo Rep: Activation Set, then do 5 reps, rest X 20 sec, another set, repeat until you can't do more than 3 reps.
 
 **Monday** 
 
 - Weighted Chinups – 4 x 6-10
 - Pullups – Myo-Rep Set (warm )
 - Bodyweight Row - Myo Rep Set (warm up set)
 - Bicep Curl - Myo-Rep Set 
 
 **Wednesday** 
 
 - Weighted Dip – 2 x 6-12 
 - Pushups - High rep - Myo-rep Set 
 - DB Lateral Raise - Myo-Rep Set 
 - Tricep Extensions 2 x 10 
 
 **Friday** 
 
 - Bulgarian Split Squat – 4 x 8-12 
 - 45 Degree Hyperextension – 4 x 10-15 
 - DB Walking Lunge - 4 x 10 
 - Single Leg Calf Raises – 4 x 10