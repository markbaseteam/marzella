> All metrics of scientific evaluation are bound to be abused. Goodhart's law [...] states that when a feature of the economy is picked as an indicator of the economy, then it inexorably ceases to function as that indicator because people start to game it. — Mario Biagioli

The economy can be likened to ourselves, and as soon as we over-optimise around a metric, be it productivity or savings in our bank account, we cease to actually be useful.

Also see: 

- [[Cobra effect]]
- [[Overfitting]]

---


### References 

> Any observed statistical regularity will tend to collapse once pressure is placed upon it for control purposes. -- [Charles Goodhart](https://en.wikipedia.org/wiki/Charles_Goodhart),