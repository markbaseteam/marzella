Mornings supps:

Pine Pollen 
Lions Mane 
Cordyceps 
Shilajit 
Ltryosine 
Tongkat Ali 
Tiny dose L-theanine 
Pink Salt in water
- 
- Active B-Complex (basically everyone is deficient in B-vitamins)
- Magnesium (Chloride or Glycinate)- tough to get from diet anymore, supplement
- Vit D- sunshine!!!
- Vit K- , fermented foods, raw milk, broccoli / spinach creamed/cooked w saturated fats/cheese
- Vit A- beef liver, carotenous vegetables (squash, sweet potato, carrot, etc)
- Vit C- oranges, strawberries, kiwis, bell peppers, etc
- Zinc- pretty good idea to supplement 20-30 mg Zinc Bipicolinate as well
- Theanine, Glycine, Creatine, Iodine, Selenium, Shilajit all solid as well

---

get off d3 and get on a comprehensive magnesium that is bicarb form with potassium, calcium, and sodium. d3 destroys potassium levels, get sunshine or red light therapy instead. add ginko per other commenter. also methylated b complex. for magnesium blend pristine hydro (has to be mixed with seltzer). b complex probably thorne or pure encapsulations. ginko just find organic and a brand that tests for heavy metals/mold


