In [[Buddhism]], unwholesome “roots” of mind which give rise to [[Unsatisfactoriness]].

Q. What are The Three Poisons?  
A. attachment, aversion, delusion

Q. What’s meant by “attachment” in The Three Poisons?  
A. keen, grasping desire for things

Q. What’s meant by “aversion” in The Three Poisons?  
A. pushing away, irritation, animosity, desire to avoid, rejection

Q. What’s meant by “delusion” in The Three Poisons?  
A. “fundamental ignorance of the nature of reality”, lack of understanding [[The four noble truths]] (varies by tradition)

Q. What are the Three Wholesome Mental Factors?  
A. generosity, [Metta](https://notes.andymatuschak.org/Metta), wisdom