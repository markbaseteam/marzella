>Tell me who you are and I'll tell you what you fear. Tell me what you fear and I'll tell you who you are.

**All fear is imaginary.**

Think of how powerful that is.

Including the fear of death.

Fear is nothing.

There is nothing there at all.

All fear is falsehood.

All fear is delusion.

All fear is lack of consciousness.

Danger is relative to what you identify with. 

Society conditions us that fear is inevitable.

Truth transcends all fear because it transcends survival.

---

Q: Isn't it healthy and normal to have fear? Isn't it a normal response.

A: It's normal in the sense that 99% of people are lost in fear. [[Normality is not a sign of truth]]
