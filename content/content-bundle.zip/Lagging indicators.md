Lagging tell you you have a problem.
