[Knowledge work should accrete](https://notes.andymatuschak.org/zTn3g4wTm1hbkNFUvLLjpev), but [[Most people only take transient notes]].

In part because [[Note-writing practices provide weak feedback]], people don’t even notice how ineffective their note-writing practices are. They develop some baseline level of note-writing skill and mostly stay there ([People generally develop skills to a plateau and then stop](https://notes.andymatuschak.org/zDV9WUPTpX5MbZb4UJEwXr1)). Expert performance is not well-defined, so it’s not obvious that people aren’t performing well ([Salience of improvement drives skill development](https://notes.andymatuschak.org/zQeW31KRF1tk2zCPPGWc7UD)). All this is true of other core knowledge work skills, too: [Core practices in knowledge work are often ad-hoc](https://notes.andymatuschak.org/zPFYKBrsvL88opKh28UYxWv).

Much of what’s written about trying to improve these practices is misguided: [“Better note-taking” misses the point; what matters is “better thinking”](https://notes.andymatuschak.org/zAf4oNSV9qB38ncSvYEZGAb)

By contrast: [Evergreen note-writing as fundamental unit of knowledge work](https://notes.andymatuschak.org/zR6RRbCfY5rFkiimFnaJZKB)