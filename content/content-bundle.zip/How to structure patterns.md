---
created: 2023-09-17
tags:
  - 0🌲
---
1. Context - sets the mood
2. Problem - identifies the problem being solved
3. Solution - beings with a one sentence resolution for the problem, and then dives into greater detail on the issues involved in applying the solutions, along with the pattern’s relationships to other patterns and supporting stories and literature
4. One or more actions - describes something concrete you can do immediately if you wish to experience the effect of the pattern
5. See also section pointing you to related patterns