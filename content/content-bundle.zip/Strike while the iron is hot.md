Very related to [[Get curious]]. The principle is: if I’m feeling energy to do a thing right in this moment, _do it!_

This principle doesn’t outright forbid “not striking while the iron is cold”—though it indirectly supports notions like [[A rigid fixation on “focus” can harm creative work]] by suggesting that if the iron is hot with some consistency, you might as well strike then and do something else now. If the iron does _not_ consistently become hot, the inverse maxim does not apply; see instead [[Just get started]] for next steps.

- This is one approach to [[Non-coercive productivity]]