An often-true colloquialism. Helps defeat blank page syndrome.

But:

- [[Inappropriate time pressures often harm creative work]]