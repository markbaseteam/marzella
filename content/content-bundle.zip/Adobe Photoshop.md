Photoshop is a good example of [[Deep collaborations between tool-makers and tool-users may support insight through making]]: it was a collaboration between Thomas Knoll, a computer science graduate student, and his brother, John Knoll, an artist working on special effects at Industrial Light and Magic.

## References

[PhotoshopNews: Photoshop News and Information » Thomas & John Knoll](https://www.photoshopnews.com/feature-stories/photoshop-profile-thomas-john-knoll-10/)