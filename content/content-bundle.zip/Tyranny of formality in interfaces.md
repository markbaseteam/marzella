TODO

---

## References

Shipman, F. M., & Marshall, C. C. (1999). Formality Considered Harmful: Experiences, Emerging Themes, and Directions on the Use of Formal Representations in Interactive Systems. Computer Supported Cooperative Work (CSCW), 8(4), 333–352. [https://doi.org/10.1023/A:1008716330212](https://doi.org/10.1023/A:1008716330212)