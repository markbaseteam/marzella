The central activity in game design: “find the fun.” Principles, frameworks, processes, etc. are all secondary to this goal. I first heard the phrase from Daniel Cook.

This core fact immediately illuminates one core reason why [[Educational games are a doomed approach to creating enabling environments]]. See also [[Skill development in games is subservient to other intrinsically meaningful purposes]].

The “fun” is expressed through _action_; see [[Games are an aesthetic medium of action]].