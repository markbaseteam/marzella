---
created: 2023-09-17
tags:
  - 0🌲
---
[[The one-punch philosophy]]
[[Process over product]]
[[Mastering the art of timing]]


"Gradatim Ferociter" - Motto of blue horizon

**step by step, ferociously**