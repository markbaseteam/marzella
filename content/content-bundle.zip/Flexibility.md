> Dynamic stretching before workout. Static stretching after. 


https://www.youtube.com/watch?v=IC4xr0CEXz0

![[Total Shoulder Mobility V2.pdf]]

![[Total Posture Mobility V2.pdf]]

![[Total Hip Mobility V2.pdf]]

![[Total Hamstring Flexibility V2.pdf]]