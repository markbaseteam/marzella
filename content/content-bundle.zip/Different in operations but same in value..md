We need to have difference. 

Everyone that's not us are NPCs in some way — make friends with the good AI bots (can learn and have a [[Sense of abundance]]) instead of the static bad bots ([[Scarcity mindset]]).