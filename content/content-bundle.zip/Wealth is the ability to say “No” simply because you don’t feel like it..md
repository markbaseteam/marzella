Obligation is an energy and usually comes from PEOPLE, not situations.

When you feel like you “have” to do something but do not really want to, pay attention to WHO is behind it.

A situation only has power over me when some part of my identity or happiness is dependent on a person involved in the situation.

If you remove the insecurity, you can remove the obligation.

If it requires me to be fake nice & fake smile, I’m not going.


See: [[Money is used to acquire in order to remove.]]