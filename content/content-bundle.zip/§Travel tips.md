---
created: 2023-09-19
tags:
  - outline
---
[[USA]]
[[Japan]]
