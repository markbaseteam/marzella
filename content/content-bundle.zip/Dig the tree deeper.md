 …not taller. Most people focus on “height” and ignore depth. You want to practice living the same way you are living now, but set up the system so that your roots get deeper & deeper. One day you wake up and realize that you are not just rich, but wealth, and that as byproduct you **no longer “need” to work for income.**

Create a minimum threshold for cash on hand (ex $20,000).

General rule is 10% of your annual income MAX.

Make every dollar above that COH _**productive**_ via a new “currency”

Take surplus OUT, reduce cash balance to a MINIMUM threshold, and trade your “cash currency” for “asset currency” thereby making it productive.

Your business needs to “fill up” the account again each month. Then you take the surplus, empty it out, and make it productive. Then, next month, fill it up again.

How do you earn $700k, live off $300k and invest $600k, Where is the extra $200k coming from?

You are now pulling from _active + passive_ income and water-falling surplus into more assets

Productive debt is the cost of acquiring an asset (bucket).