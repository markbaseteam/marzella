It’s nice to be disciplined and ambitious, but having gumption is even better. [[Gumption]] is the inspired, agentic feeling for an activity which makes it no longer _require_ willpower or confidence.

Gumption comes easily when activities have intrinsically meaningful purposes. It’s readily sapped by nonsense. Related: [[Enabling environments’ activities directly serve an intrinsically meaningful purpose]]

---

## References

Pirsig, R. (1979). _Zen and the art of motorcycle maintenance: An inquiry into values._ New York: Morrow.