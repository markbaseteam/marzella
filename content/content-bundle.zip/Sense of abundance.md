---
created: 2023-09-17
tags:
  - 0🌲
---
Expansive, curious, open, unfearful, unhurried. The opposite of [Scarcity mindset](https://notes.andymatuschak.org/z99vBTQN4Rp1DSxZDYpAufr).

Related:

- [Process over product](https://notes.andymatuschak.org/zY4QE4Q6NJpGZZh4Binv2xB)
- [Inappropriate time pressures often harm creative work](https://notes.andymatuschak.org/z9TuEpnqEtLdy2TWWVicLsU)
- [Get curious](https://notes.andymatuschak.org/z5zoV8TdSds59vQEkqp3JEz) / [Get playful](https://notes.andymatuschak.org/zQ48c3CqTAtpJJ2itF7Uu85) / [Get bored](https://notes.andymatuschak.org/zL7p6gaECTXdiirrFVSUTAW)