---
category:
  - "[[Recipes]]"
cuisine: 
type: []
ingredients: 
author: []
url: 
rating: 
created: 2023-09-23
last: 2023-09-23
tags:
  - recipes
---
Bored of steak? Tired of bland minced meat? An EASY way to spice things up is by making kebabs. You transform soft lean mince into a burger like, mouth watering sensation.

## Ingredients

- 2lb seasoned lamb or beef (add any spices you want, could use harissa as a base)
- 50% tomato paste, 50% spicy pepper for marinade
- Vegetables can be added in between the meat if you like to 

## Directions

- Add minced meat & marinade sauce in a bowl.
- Knead until incorporated & make 8 balls.
- Spread evenly on middle part of skewer.
- Set skewers on grill and give them enough space
- Keep turning the skewers to the temperature you like 

## Notes

- Note: Use 80/20 meat and it needs to be EXTREMELY fine, mince it a few times if you need to. Serve with grilled vegetables or rice. 