> _“Iron rusts from disuse; water loses its purity from stagnation... even so does inaction sap the vigour of the mind”_ – Leonardo da Vinci

---

Without action, everything else is merely fantasy.

The only way to create what you want is to take relentless action in that direction.

Your body becomes weak when you don’t train…

Your mind becomes ignorant when you don’t read…

Your spirit becomes lifeless when you don’t experience…

That’s the default for most people, they are dying on all levels.

See also: [[Proactivity and personal responsibility]]

What about rest and relaxation?

Rest and relaxation can still be action if another facet picks up that movement.

Example being when you rest / meditate you’re giving your spirit movement.

The times where every facet comes to a standstill is when you atrophy and become depressed.

At least one area has to pick up the slack of the others.

If internal benefits weren’t enough….

If you just do the bare minimum you will become a battery for the matrix.

Powerful systems outside of your awareness will co-opt your consciousness to feed their survival and serve their low consciousness priorities and outright devilry.

You will become an intellectual slave without even realizing it.

Everything is connected.

[[Your brain]] is connected to [[your gut]] which is connected to [[your musculoskeletal system]]…

…which is connected to [[your breath]] which is connected to [[your hormones]]…

…which is connected to [[your immune system]] which is connected to [[your metabolism]]…