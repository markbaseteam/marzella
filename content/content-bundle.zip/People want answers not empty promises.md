The customer is NOT always right! Great customers know this. They want answers and actual problem-solving, not an empty promise to "fix it."

Being proactive TRUMPS reactive. Customers admire when you analyze and propose improvements on your own, rather than waiting for issues to surface.

Long-term success > short-term gains. Don't fall for quick fixes; invest in lasting solutions to generate superior outcomes and cement lasting partnerships.


- Practical solutions
- Partners for your journey
- Reliable, consistent delivery
- ‘What everyone else is doing’
- Safe bets that don’t get you fired