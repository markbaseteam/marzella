Never settle for a status quo that rubs you the wrong way. Use your creativity and courage, in ways small and large, to nudge your corner of the internet in a healthier direction. Focus your energy on creating more of what you want to see in the world, trusting that others will follow suit.

See: 

- [[Create invitations, not ultimatums]]
- [[Work with the garage door up]]