Everyone wants to find someone who's perfect, while ignoring the fact they they themselves aren't perfect and still evolving. It's not about who's perfect. It's who's perfect for you. And perfect for you is someone who also recognises that growth happens together and perpetually.

See: [[See things as they are, not how you think they should be.]]