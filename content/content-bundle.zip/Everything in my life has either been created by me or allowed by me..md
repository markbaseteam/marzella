I own my time. I am wholly responsible for my outcomes.

I never want to be able to point to someone and say: “Well, if it wasn’t for X, then I would have Y”

Using time to build things that will give you more ownership over your time.

The things in my life create money for me versus my time.