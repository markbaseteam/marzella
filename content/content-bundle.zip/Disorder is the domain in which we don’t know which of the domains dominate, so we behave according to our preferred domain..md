---
created: 2023-09-19
tags:
  - 0🌲
---
Humans have the natural tendency to treat complex situations as if they can be analyzed, and making plans and commitments based on that flawed analysis.

For Motis Group our biggest failures have come from treating complex problems as if they’re complicated, because:

1. The client underestimates the fluid nature in achieving the end result which is a moving target and gets upset when we don’t reach it fast enough.
2. We fuck up on pricing the project because we price on a fixed fee and we’ll likely go over those hours.

When disorder persists, chaos is the inevitable result.

To solve for this and de-risk misinterpreting a problem type in discovery we can ask:

“_**Who’s done this before?**_”

…and use the below answers to figure out what domain we’re in: