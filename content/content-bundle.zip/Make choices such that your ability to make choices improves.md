
> Choose the option that gives you the most options 

-- My Dad

When it comes to financial wealth and career building because [[Acting in the space causes the space to change, and cause and effect can only be understood in retrospect.]], there's no point in trying to analyze all the options upfront.

Which person should I talk to?

What will happen if XYZ?

Blah, blah, blah.

Usually they're [[Champagne problems]]

And most answers will only become clear in hindsight.

Q: So what decision do you make?

A: The option before us that will enable us to operate in the complex space more effectively.

Money follows responsibility. If you want more, become responsible for more. 

Expand your choices until the deciding on the choices themselves is itself limiting.

[[Scale is when you have full market share without compromising value.]]

At this point you can cut back and re-focus your energy on the core areas that open up more space for the next project.

I suspect these moments of cutting back / re-evalutation will form the chapters of your life.

See:

- [[What is the point of moving or staying in the USA?]]