Learning through pain.

Failure teaches us more than success.