---
created: 2023-09-19
tags:
  - 0🌲
---
Software: Simple and intuitive to use. Simplify the complex processes and expose them in the simplest manner possible to the developer.

You: Explain complex ideas in a simple way. Having clear and straightforward communication. Not over-communicating. Make it easy for people to pay you.

Why? Valuable in roles like teaching, consulting, or any position that requires making complex things understandable for others.