---
created: 2023-09-17
tags:
  - 0🌲
---
When you go out in downtown the level of thinking required to have a simple meal massively outweighs the actual meal.

You have to drive there…

Worry about parking…

Get there on time because it's busy…

Line up to get in…

Pay to get in…

Line up for drinks…

Pay for drinks…

Worry about an increased crime level…

…and deal with drunk people acting stupid.

The juice is not worth the squeeze.

Instead, I enjoy being able to show up to a place when I want and not have any obligation of being there other than wanting to be there.

I don't have to get to Piatti at 7 pm sharp because there's a line or they have a special deal to get in.

I go there at any given time because it's a consistently nice experience that has a very low emotional investment.

Consequently, the emotional result is so much more enjoyable because I haven't wasted half my energy stressing about getting there.

When adding new options to my life, I try to integrate them into my existing daily routine.

For example, I prefer ocean swimming to using a cold plunge tub because it takes less time to set up and provides the same benefits.

By doing this, I avoid diverting too much from my path and avoid resistance.

See: 

- [[Friction tells us the truth]]

---

### References