Software: Clear versioning strategy. Managing changes and ensuring backward compatibility for the users of the API.

You: Ability to learn and adapt over time, or the willingness to change and improve. Evolve and innovate to stay relevant in changing market conditions. Also being sure to provide communication on changes so that customers aren’t left behind.

Why?