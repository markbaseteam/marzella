

![[Pasted image 20230922181204.png]]

**The American dream only makes sense for people who's marginal utility of income is HIGH**.

Those who enjoy the American dream the most are those who need it the most.

It's an attractor for people who experience significant life improvement with every dollar earned.

It all comes down to:

	1. What type of work are you doing?
	2. How much you are being paid for said work?
	3. What is the location you're coming from?

1. The type of work constrains you to location when that work can only be done in a physical place -- i.e manual labor. Knowledge/info work does not apply.

2. How much you're being paid for said work is also a big component of whether to stay in any given location. The more you're being paid the more proclivity you'd have for taking risks and moving.
   
3. If the job market sucks for that job (and if you can't arbitrate into another country's market) then this also contributes.

For me I think the more money I'm earning, the more proclivity I'd have to leaving and moving somewhere else. It's interesting, the increase in security creates a desire to experience insecurity. Why?

