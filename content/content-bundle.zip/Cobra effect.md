When incentives designed to solve a problem end up rewarding people for making it worse.

In regards to accumulating material wealth, it only amplifies who you already are.