---
created: 2023-09-17
tags:
  - outline
---
[[Good APIs are consistent]]

[[Good APIs are simple]]

[[Good APIs are comprehensive]]

[[Good APIs are reliable]]

[[Good APIs are secure]]

[[Good APIs are performant]]

[[Good APIs have a changelog]]

[[Good APIs error handle]]

[[Good APIs have an intuitive pricing structure]]