He comes as everything you ever wanted.

Be careful of those who offer easy access to your desires. Nothing comes easy. Needs are cheap. Wants are expensive: status, exclusivity and emotional value.

**Believable people**: Those who have repeatedly and successfully accomplished the thing in question – who have a strong track record with at least three successes – and have great explanations of their approach when probed.