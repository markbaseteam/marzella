
- **Conceptual** (Macro) — This is the high-level perspective, philosophical, theoretical, existential
  
- **Practical** (Meso) — No fancy language, just the actual how-to of something
  
- **Technical** (Micro) — The nuts and bolts, diving deep into the specifics of a thing