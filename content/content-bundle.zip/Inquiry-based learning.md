See e.g. [[Moore method]]

More generally: [[Constructivism]]
## Related

- [Educational environments usually don’t involve original thought](https://notes.andymatuschak.org/zQDtyijWebs1Su1Z8rZptot)
- [[Internally-modulated learning is self-actualizing; externally-modulated learning is self-abnegating]]
- [The Young Lady’s Illustrated Primer](https://notes.andymatuschak.org/zCjT6omFavtr7Zx2S5do6qC)