1. [[Be the best at what you do]]
2. [[Become irreplaceable]]
3. [[Be on market trend]]