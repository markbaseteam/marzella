---
category:
  - "[[Recipes]]"
cuisine: 
type: []
ingredients: 
author: []
url: 
rating: 
created: 2023-09-23
last: 2023-09-23
tags:
  - recipes
---




## Directions

- 

## Notes

|Place|Tips|
|---|---|
|Sushi Ippo|Alaskan|
|Rainbow roll||
|Ultimate Orgasm||
|Rolls Royce roll||
|Hotel California||
|Seared salmon||
|Hurricane||

**Tempura Rolls**

- Rolls Royce roll
- Hotel California

**Fresh Rolls**

- Alaskan
    

- Rainbow roll
    
- Ultimate Orgasm
    

- Seared salmon
    
- Hurricane