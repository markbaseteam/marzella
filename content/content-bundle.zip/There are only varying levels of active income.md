---
created: 2023-09-17
tags:
  - 0🌲
---
The biggest lie (through omission) is "PASSIVE INCOME".

Beginners get sold the dream of "make money without work" because it is easy as fuck to sell.

The truth?

The type of person that can ACTUALLY create (and manage) a passive income stream is a person that has spent YEARS cultivating a stack of very specific skills.

And even then - "passive income" isn't the correct term. The correct term should be something like "delayed payment income" because you will be doing a monstrous amount of work to set up a system that will (one day) pay you passively.

"But what about real estate!?"

Real estate is one of the worst routes for passive income. Especially for beginners. Dudes could take the exact same amount of money they are dumping into their properties to scrape off $1,000/mo and buy an internet business + hire an OBM (online business manager) with the same amount of money and make 5-10x more per month. You'd be kicking out $5k/mo instead of $500.

You can only create "passive income" for yourself after you know HOW to do it. And you'll only know HOW to do it by mastering skills for the next 3-4 years.

Focus on first mastering a skill and using that skill to make money on the internet. Run that skill up to $1m/yr. Then worry about other things.