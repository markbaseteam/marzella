Three two-day holidays are not nearly as restorative as a single six-day holiday.

This is partially due to transaction costs—there’s always lots of obligation, scheduled stuff, and stressors at the start/end. But it seems to also stem from the fact that restfulness comes from a significant change in routine, which takes some time to fall into place.

On the other hand, [[Short vacations can somewhat postpone the need for a longer vacation]].