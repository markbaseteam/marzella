**Natural Places**

- Acadia
- Monhegan Island
- Bryce Canyon
- White Mountains
- Olympia
- Big Sur
- Joshua Tree
- Saguaro
- Big Bend
- Smokey Mountains
- Zion
- White Sands
- Rocky Mountains
- Four Corners
- Grand Canyon
- Glacier
- Black Hills

|Name|Location|Server|Best time to go|
|---|---|---|---|
|Wolfies|Little Italy, SD|ask for bartender Chris|Thursday- Sunday|
|Piatti|La Jolla Shores|Ask for server Aubrey||
|Brick & Bell Cafe|La Jolla Shores|Aida, make the coffee with love||