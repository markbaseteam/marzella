A central piece of [[Buddhism]]:

- [[Unsatisfactoriness]] is an innate characteristic of existence
- the cause is [[Tanha]]
- the ending of [[Unsatisfactoriness]] can be achieved by eliminating all [[Tanha]]
- [[The Eightfold Path]] is the means

Q. What are the four noble truths?  
A. suffering (dukkha) is ubiquitous; the cause is craving (tanha); its cessation comes from eliminating craving; the eightfold path is the way.