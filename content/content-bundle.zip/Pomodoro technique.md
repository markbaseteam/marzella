In reference to my own practice:

- [2022-11 November](https://notes.andymatuschak.org/zLfnhMHRptAZFzUcNzyvTUP): now using 55m pomos when starting before 10AM; 45m before noon; 25m after, following data from [Project - pomodoro experiment](https://notes.andymatuschak.org/zEHZYJniHHwiDyFU29HBhbx); practically speaking this usually means my morning goes: 55 55 45 45 45 25 25 [25](https://notes.andymatuschak.org/zQTBAGqGvVQVvRntB69GNPi?stackedNotes=z2EeBFS91iTHhSkdmXqhTns&stackedNotes=zKAXykV6vxcnSNEpT2LfyWG&stackedNotes=zSkiQC8doMdCAMwTeiXgjXx&stackedNotes=zJwcvZbtq2iQwpd63Go9tD4&stackedNotes=Pomodoro_technique&stackedNotes=z6yUMNozmk9oamZmKFn5Ldh) (~5.5hrs active time in ~6hrs of clock time)
- Switched back to 25m/5m pomos in Jan 2022 as part of [[Program - finish my workday in the morning]]; focusing on longer contiguous blocks (6hr instead of 4hr, no long breaks) and higher-quality deep attention on harder tasks rather than trying to optimize efficiency
- Switched to 40m/5m pomos on [2021-07-12](https://notes.andymatuschak.org/zDXxMq3D7hNxdMhrGS3GL71)
    - So goal for the morning block is 6 45m pomos.
    - 8h of working time is 12 pomos
    - 55m of break time spread within those 12
- Switched to 35m/5m pomos on [2020-01-22](https://notes.andymatuschak.org/z9dPezxRaee6hzm7G7hGdHB)
    - Goal for the morning with this block size is 7 40m pomos
    - 8h of working time is ~14 pomos
    - 65m of break time spread within those 14