We transact capital for human energy.

The difference between whether something owns us or we own it is the return on energy invested into that thing.

If it demands more energy from you than the energy equivalent in capital then it owns you.

Invest your time in activities where the money earned can buy you more human energy than what you put in.

Invest your time in activities that will lead to more money and more time to invest in activities that lead to more time.

Owning your time. It’s about where what the market pays for your time matches your perceived value of that time.

Your time should have an outsized return.

Using time to build things that will give you more ownership over your time.

See: 

- [[Everything in my life has either been created by me or allowed by me.]]
- 