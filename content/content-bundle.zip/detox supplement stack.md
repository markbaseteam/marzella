- Black seed oil. 3 tbsp/day
- Pine nettle tea. 1-2 cups/day
- Dandelion root tea. 1-2 cups/day

Now, to purge your body of heavy metals.

Take these:

Selenium: protects against toxicity Magnesium: protects against damage done Milk Thistle: protects liver from metals Zinc: lowers metal absorption Copper: excretes metals Activated charcoal: flushes metals

Chlorella: binds to & removes metals Apple pectin: super potent detoxifier NAC: pumps glutathione, reduce ox. stress Niacin: binds to lead and mercury

NCD2 zeolite

Carbon 60 Bentonite clay: high negative charge, binds metals

---

Diet

Cilantro: binds Broccoli: glucoraphanin Garlic: powerful antioxidant Bluberries: powerful antioxidant Onions: sulfur Avocado: glutathione Carrots: beta-carotene Turmeric: anti-inflammatory Seaweed: phytochelatins