Buy them _**********indirectly**********_ via ASSETS

Ex. A new car “costs” $1,500 per month. An investment vehicle that can spin off $18k per year ($1,500 x 12 mo) @ ~15% would required $120k placed for the year.

End of the term you can return car, _**********************get full capital back,**********************_ and how much did it cost you? $0

Same with anything (watches, jewelry, vehicles, etc)