“I’m not doing enough”; “I don’t have enough time for X”; etc. By contrast, see [[Sense of abundance]]

