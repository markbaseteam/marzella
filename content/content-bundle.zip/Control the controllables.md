INPUTS (Things you can take care of) - your friends; your lifestyle; your mentality; your daily schedule; your activities; work experience.

SYSTEMS (Things you can get other people/things to do) - automation; delegation; subtraction; innovation.

OUTPUTS (Things you don’t need to touch that will take care of themselves) - $; awards; publicity.

FEEDBACK (Reflection on your outputs and changing inputs) - Are you achieving everything you need to? What do you need to change?