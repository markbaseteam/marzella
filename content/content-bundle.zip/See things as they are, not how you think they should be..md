To see ourselves and a person as he/she is, to be aware of their unique individuality.

---

### References

Fromm, E. (1956). The Art of Loving. Harper & Brothers.

>Respect means the concern that the other person should grow and unfold as they are. Respect, thus, implies the absence of exploitation. I want the loved person to grow and unfold for their own sake, and not for the purpose of serving me. 

>It is clear that respect is only possible if I have achieved independence, without having to exploit anyone else. Respect exists only on the basis of freedom, for love is the child of freedom, never that of domination.