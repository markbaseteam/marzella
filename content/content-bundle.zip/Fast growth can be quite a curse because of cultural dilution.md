It’s interesting what “dilution” even _means_. Diluted with what?

Fools, clowns, bandits and assholes.

1. Assholes: malicious & contemptuous.
2. Bandits: Extract value at cost to others (can be polite while they do it).
3. Clowns: Court attention at any cost.
4. Fools (the most dangerous): just plain stupid and unpredictable, causing unexpected damage for no discernible reason.

If you want to grow without cultural dilution you need:

- Have high standards when inviting noobs
- Enforce standards (ie penalise players who fail to follow the rules)
- Have regular sermons to remind everybody about community standards, rules, goals (create cultural norms)

See: [[Premature scaling can stunt system iteration]]