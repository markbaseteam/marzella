rom Systemantics: How Systems Really Work and How They Fail:

> A complex system that works is invariably found to have evolved from a simple system that worked. A complex system designed from scratch never works and cannot be patched up to make it work. You have to start over with a working simple system.

---

A complex system that works always evolves from {a simple system that worked}.

Q. Gall’s Law suggests what cure if you find yourself struggling with a complex system that doesn’t work?  
A. Start over from a working simple system.