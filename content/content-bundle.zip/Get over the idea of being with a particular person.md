Unlike women, men love idealistically. To a man, love is a principle that is greater than himself.  Men don't use love as a survival tactic, like women do. Men latch onto a belief that his love was special, and meant to be. Thus, men take longer to get over heartbreak.

You can’t get over your ex because you mistakenly think “_she is special, unique and one of a kind._” You project all sorts of silly idealisations unto her.

Your imagination inflates her worth sky-high, and rationalises away her flaws.

You have nothing else exciting going on in your life, so you end up daydreaming about her - further increasing her perceived worth.

She is nowhere near as valuable as your emotions trick you thinking she is.

It’s not the girl you like, but the addictive feelings you feel.

You didn’t realise that she wasn’t the girl of your dreams.

It was the dream that made her divine, not her making the dream.

Your emotions are tricking you into erroneously concluding that she is special, unique and supremely important.

There’s millions of girls just like her or even better out there.

You’re in “love” with your false perception of idealization, & addicted to certain feelings.

**These are feelings that any girl could give you - given the right conditions.**

Don’t fall for the illusion of believing in her inflated worth just because you had some shared experiences. The ONLY way you can forget about an EX is to be adored by women who are objectively better than her.

Find women who are better looking/younger/more useful. Focus on a much hotter and cooler girl - who has an even better personality.

Would she remember me more if we broke up now and spends her time thinking what could have been the rest of her life, or stay with her long enough to grow apart and forget about me and lose love anyway?

Improve in solitude. Use your time alone chasing your goals and learning how to make yourself happy. When your life has meaning, heartbreaks from former relationships fade away because you’re too busy to give a fuck.

By doing this, the thought of your EX will never even cross your mind. This will create more mental energy for pursuing leads that are NOT dead-ends. How can you spend time thinking and planning for a better future if you are wasting away your time dwelling on the past?

Summed up best, by an artistic man I had the pleasure of drinking with in 2018:

> “_There are so many beautiful, complex people here, that are begging to be discovered…why would you still be worrying about some trick at home?_” – Michael Linowitz

People come, people leave. Never stress over what isn't yours.

Her actions post breakup define if she was really meant to be or not. If you split and she acts like a whore to annoy me. The only person getting upset at her ratchet ass self is her father. This just shows her true immaturity and nature.

Any time a relationship for you has ended in a breakup is because you’ve lost the original self that the girl was attracted to in the FIRST place. You've neglected your masculine duties towards achieving your life mission – you've taken your mind off goals, hustling with passion and purpose and working towards a vision. You gave your all to her and ignored yourself. She became the centre of attention, when YOU should be the centre. Continuing to feed the monster you allowed to create.

There are two paths from heartbreak:

1. Let it consume and destroy you and never be able to love again, or
2. You can free yourself into love. Get better, not bitter.

You must live with an open heart even if it hurts.

You’re clutching at what doesn’t exist anymore, it is in the past. A different timeline.

You are here now. That’s what matters now. All life is an act of faith and an act of gamble.

The course of wisdom, what is really sensible, is to let go, is to commit oneself, to give oneself up. Fuck the past and let go of everything negative from it. It's time for you to invest that love and attention back into yourself.