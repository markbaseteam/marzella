On vacation, each new day is a big blank canvas. This can be anxiety-promoting! ([[FOMO on vacation disrupts restfulness]]) A default routine can help keep things smooth. You don’t have to decide anything: just do the thing you’d already decided was good to do.

On my trip to Maui in January 2020, I had the same routine every day, and it was great:

1. wake up; work until the sun’s up
2. read/write/sit on Wailea Beach
3. eat lunch simply nearby ([[Defaulting to boring food choices disrupts FOMO on vacation]])
4. read/write/sit on Wailea Beach
5. watch the sunset at Whale’s Tale, a nearby bar
6. chat briefly with housemates and sleep