*Stronger from stressors!*

Obi-Wan Kenobi's quote from Star Wars always reminds me of Antifragility:

> *"If you strike me down I shall become more powerful than you can possibly imagine."* 

In a sideways way, this ties into the metaphor of the phoenix being reborn from the ashes of the dragon—and of the hydra having its head cut off, only to have two replace it. 

Using alliteration, it's: getting **stronger from stressors**, more settled from shaking, more adaptable from attacks.

In a way, antifragility is a faster form of [[Natural Selection]].

Antifragility is closely related to resilience/robustness, although resilience shouts *"Still standing after stressors!"*

### Unsorted
- [[Hormesis]] and the [[Lindy Effect]]
- Eventually, tie this into my other thoughts: [[201509091056]] (not included in the LYT Kit)
