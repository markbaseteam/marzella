
1. you can pay your bills and your rent without stress
2. you can eat at any restaurant without looking or worrying about the price
3. you can travel wherever you want without worrying about the price
4. you can choose how you travel without worrying about the price
5. You can work on what you want without worrying about income