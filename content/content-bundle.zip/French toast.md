---
category:
  - "[[Recipes]]"
cuisine: 
type: []
ingredients: 
author: []
url: 
rating: 
created: 2023-09-18
last: 2023-09-18
tags:
  - recipes
---
## Ingredients

- 2 eggs
- 1 cup heavy cream
- 4 Tbsp sugar
- pinch of salt
- pinch of cinnamon
- drop of vanilla extract
- challah bread (or brioche)

## Directions

1. Mix all ingredients (except bread) in a mixing bowl to form the batter.
2. Cut thick slices of challah bread and soak thoroughly in batter.
3. Butter a pan and cook each slice at medium heat (I use a stainless steel pan) until each side is golden brown.
4. Dust each side of the bread with a light coating of sugar, then flip over and cook for an additional 5-10 seconds. This forms a crystalized layer of sugar on the outside of the bread.
5. Serve with the best syrup you can access (I buy whisky barrel-aged syrup at my city’s Christkindl market)

## Notes

- 