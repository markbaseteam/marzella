[[Restful vacation time doesn’t add linearly]], but if the next opportunity for a long vacation is far away, a few 1-3 day restful trips can incrementally extend one’s period of well-charged operation.

Short vacations should otherwise be used for adventure, variety, and play.