---
created: 2023-09-17
tags:
  - 0🌲
---
Vote with your actions.

Just chill and wait until next week. Don’t act like a spoilt brat…

You’re sitting pretty with Tray

The more it takes the better you get to assess how they make decisions and reach agreement. That’s valuable before you jump in.

Right, it’s like their actions now are really showing their true colours. But then again am I supposed to accept that because they’re a startup?

Yes. They are young and inexperienced. And even established companies don’t get it right. You don’t know what they need, internal politics etc. You need to put your focus on something else. Otherwise, you’ll burn out. Read a book wrote some music - work for Tray…