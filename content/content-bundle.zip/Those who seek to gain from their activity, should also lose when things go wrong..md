---
created: 2023-09-17
tags:
  - 0🌲
---
Have a look a this LinkedIn profile.

[https://www.linkedin.com/in/carl-nygard/details/experience/](https://www.linkedin.com/in/carl-nygard/details/experience/)

Below is a mapping out of his career.

![[career-progression.png]]

Notice something?

This man was in the trenches for 8 years before he even touched consulting.

He doesn’t have a YouTube channel.

He doesn’t sell a course.

[[Unstandardized outcomes cannot be standardized.]]

Meanwhile all these retards are trying to become “EXPERTS” just by watching YouTube vids.

And the gurus are selling these retards:

![[guru-1.png]]

![[guru-3.png]]



> “Beware of the person who gives advice, telling you that a certain action on your part is “good for you” while it is also good for him, while the harm to you doesn’t directly affect him.” — Nicolas Taleb

They may close some clients but it’s all the same — dweebs and squids selling and buying from dweebs and squids.

You wanna close the BIG biz?

Earn your stripes in the Trenches for an insanely LONG time.

Learn some stuff. 

Achieve.

[[Pathemata mathemata]]

THEN sell your expertise.

My uncle is making $5M a year at 50.

He worked his ASS off for 25 years before he became a consultant.

Why is he able to charge this much?

Because he solves hard problems.

He spent many years accruing a random selection of skills and experiences - and deployed them against many different types of problems.

So how do you get started?

First of all right now, don’t try and be the strategy guy.

You have no idea on what strategies work and don’t work.

Focus on doing the work and then you can draw the insights backwards once you’ve accrued the experience.

You’re going to be facing an uphill battle with Motis Group, there are plenty of technology consultancies out there, that are bigger and are equipping with more skilled people.

Do a bit of everything:

1. Work the 9-5
2. Start your own thing on the side
3. Join a successful consulting firm.

DO IT ALL.

1. Work for startups for a couple more years (2021 — 2029), get into a management position.

2. Start Motis Group and start consulting people independently (2029 - ongoing). Once you get into a management position (you’ll be able to help strategise more effectlively, as well as have more time to serve clients on the side because you’re no longer in the trenches at the W-2.
    
3. Keep running Motis Group and then join a big consulting firm (2037).
    
    [Thoughtworks: Delivering extraordinary impact together](https://www.thoughtworks.com/en-us)
    

Your task is to find a unique niche within tech (sales, APIs and AI) - using AI to make information gathering and querying easier.

Point is that you can be patient because you’re collecting knowledge now.

You don’t have to be UBER rich in 3 years. It’ll all go to waste anyway.

Funnel money into RE investments and long term assets.

[[Keeping the main thing the main thing]].

Grow slowly but surely.

Patient but furious.

You’ll get there.


---

### References

- Taleb, N. N. (2018). Skin in the Game: Hidden Asymmetries in Daily Life. Random House.
  
	“Giving advice” as a sales pitch is fundamentally unethical—selling cannot be deemed advice. We can safely settle on that. You can give advice, or you can sell (by advertising the quality of the product), and the two need to be kept separate.