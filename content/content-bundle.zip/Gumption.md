The essential fuel for doing hard creative work.

- [[Gumption transcends willpower and confidence]]

## References

Pirsig, R. (1979). _Zen and the art of motorcycle maintenance: An inquiry into values._ New York: Morrow.