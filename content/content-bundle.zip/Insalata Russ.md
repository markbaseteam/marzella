---
category:
  - "[[Recipes]]"
cuisine: 
type: []
ingredients: 
author: []
url: 
rating: 
created: 2023-09-18
last: 2023-09-18
tags:
  - recipes
---
## Ingredients

- 1/2 Red Pepper - finely chopped
- 1 red Onion Jooshed In the blender
- 3 stalks of celery - peeled and finely chopped
- 2 cans of peas
- 6 soft boiled carrots - peeled. Chop in half then boil. Put in fridge until cool. Finely chop after boiling.
- 8 Red potatoes boil on low heat simmering with skin on until fork soft.
- 12 hard boiled eggs
- 1 tub of mayonnaise
- Salt - 2 pinches salt
- lemon juice - 1/2 lemon squeezed
- vinegar - 1 tblspn
- sugar - 1/2 tblspn

## Directions

1. Boil potatoes and carrots whole and eggs first.
2. Then put in fridge to cool off.
3. Peel and chop.
4. Mix potatoes, carrots, pease, onions, celery, capsicum and 1/2 the tub of mayonnaise.
5. Add salt to taste.
6. Get the other half of the mayo and mix with vinegar and lemon juice and sugar to taste. Should be sweet and acidic.
7. Mix this all together with the rest of the salad.
8. Chop and add 3/4 of the eggs, mix salad again.
9. Slice the remaining eggs and put on top as garnish.

## Notes

- 