It's about picking the right race to run. 

Focusing on becoming useful in industries where tangible value is being created (real estate development, mining, engineering), not industries where value is being "assessed" or shuffled around (financial markets, money, trading stocks, banking).

Ultimately, you end up picking a race that you'll want to keep running even when it comes to a "finish". Work that you would do regardless of money. 

> Here's the irony: By working as if you don't need money, it finds it way to you.

That's how you escape the rat race.

### References

Conversation with [[Dad]] - [[2023-09-01]]
