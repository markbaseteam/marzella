I’m very sensitive to being under slept, and vacation is full of threats to a good night’s sleep:

- uncomfortable, too-small, or unfamiliar bed
    - -> double down on making sure the destination has a queen+ size bed, or at least two twin beds
    - -> remember that cheap Airbnbs often buy very cheap bedding, so it may be worth paying a lot more for better bedding
- traveling without CPAP
    - -> prioritize this! pay the baggage fees if necessary
    - -> maybe buy a travel CPAP?
- staying up too late doing activities
- drinking too late
    - -> don’t!

I’ve noticed that I’ll often find myself sleepy and unable to focus for much of the time I’m on vacation, which sort of defeats the purpose.