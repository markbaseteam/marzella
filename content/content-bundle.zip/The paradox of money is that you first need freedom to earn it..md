Freedom allows you to control what you work on. If you control what you work on then you can work on what you love. If you love it you will do it for a long time. If you do it for a long time you will get really good at it. Money will come as a result.

[[Materialistic focus leads to materialistic decline]]