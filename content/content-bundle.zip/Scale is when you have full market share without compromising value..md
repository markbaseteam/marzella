Market cap of a business is the equilibrium point at which the increase in profits is no longer worthy of the increased risk exposure. It’s when growing a business past its current level incurs more risk than benefit.

In my mind, this is where you put the humans you serve at risk.

See: [[Scale can kill authenticity]]