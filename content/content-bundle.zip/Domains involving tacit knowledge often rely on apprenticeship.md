You can learn lots of skills by watching YouTube explainer videos, or by reading a book. But it’s hard to learn how to be a good researcher or a good designer. And so on. One key reason seems to be that these domains involve a lot of [[Tacit knowledge]]. Such domains tend to have a strong tradition of apprenticeship or mentorship. And it’s often very difficult to learn the skills of the trade without that avenue.

See: [[The one-punch philosophy]]

