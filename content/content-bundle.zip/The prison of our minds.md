---
created: 2023-09-17
tags:
  - 0🌲
---
I had a dream where I was in a prison that could be left at any time.

Everyone had aspirations to be great writers, but everyone couldn’t see that they could leave the jail.

There were no fences.

No guards keeping them in.

When asked what their sentences were, they weren’t too clear but they sounded self imposed.

This happened to me…instead of I happening to it.

People couldn’t believe that I had been outside the walls.

It was like a college that people didn’t WANT to leave more than anything.

We are writers of our own lives that live in self-imposed prisons.

The assumption we hold.

The beliefs we have.

Form a box around us, they define us.

But it can also trap us.

See: 

- [[External movement does not detach us from ourselves]]