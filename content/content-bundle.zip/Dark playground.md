Concept via [Tim Urban](https://notes.andymatuschak.org/zJRDn3hcKmqNAKrMQUF6XvY): what happens when you’re evading what you’re “supposed to do” with distractions… but you don’t allow yourself to even _enjoy_ those alternatives because you’ve convinced yourself you’re “supposed to” be doing something else. The worst of both worlds!

Resolutions:

- [[A rigid fixation on “focus” can harm creative work]]: relax the fixation on being “productive” and just enjoy yourself. [[Get playful]].
- [[Just get started]]