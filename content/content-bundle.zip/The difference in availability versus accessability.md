It's essential that "availability" isn't confused with "accessibility."

You want to be available to your people, customers, etc.

You must get less accessible as your org grows. Otherwise, you'll never get to important work.

1. Let's say someone is stealing big money, everyone in your org should feel you're available to hear directly about that.
2. But, you shouldn't be so accessible they interrupt whatever you're doing and go straight into your office.