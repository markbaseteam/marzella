---
created: 2023-09-17
tags:
  - 0🌲
banner: "![[0c7b7bd6de1525cecb762d4f3de34ea1.gif]]"
---
# Keeping the main thing the main thing.

If you don’t sacrifice for your goal, your goal will become the sacrifice.

[[Deep understanding requires detailed knowledge of fundamentals]].

Knowledge of the fundamentals requires [[Walking the path of the master]].

See: [[The one-punch philosophy]]