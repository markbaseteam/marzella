All these systems exhibit self-reinforcing growth. Better utility attracts more usage, which calls for more resources and innovation, attracting even more users.
