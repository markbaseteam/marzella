---
created: 2023-09-19
tags:
  - 0🌲
---
Software: robust security measures to protect sensitive data, using techniques like authentication, authorization, and encryption.

You: Maintaining confidentiality, respecting others' privacy, or generally behaving in a trustworthy manner. Safeguarding customer data, maintaining secure operations, or complying with regulations. You tell people what is relevant to them and them only

Why?